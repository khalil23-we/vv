export type VaccineDataObject = {
  [key: string]: any
}
const vaccineData: VaccineDataObject = {
  india: 'https://www.cowin.gov.in/home'
}

export default vaccineData
