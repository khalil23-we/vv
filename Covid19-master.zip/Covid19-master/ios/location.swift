//
//  location.swift
//  Covid19
//
//  Created by Sarthak Pranesh on 11/10/20.
//

import Foundation
