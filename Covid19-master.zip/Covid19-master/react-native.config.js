module.exports = {
  assets: ['./assets/fonts']
}
